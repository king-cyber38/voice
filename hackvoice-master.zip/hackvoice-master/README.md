# hackvoice
هک میکروفون گوشی با ارسال لینک - Hack microphone by sending link            
<a href="https://t.me/hackgm"><h2>T.ME/HACKGM<h2></a>
کد های اجرا در ترموکس :
<pre><code>
<br>
apt update
<br>
apt upgrade 
<br>
pkg  install  wget  php  git openssl 
<br> 
git  clone https://github.com/HACKGM/hackvoice
<br>  
cd hackvoice  
<br>
bash voice.sh  
<br><code><pre>

